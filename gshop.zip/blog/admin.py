from django.contrib import admin
from .models import BlogEntry

# Register your models here.
admin.site.register(BlogEntry)
