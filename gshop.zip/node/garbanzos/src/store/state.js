import makeState from "@/factories/state-factory";

/*
Aqui va toda configuracion extra del estado de aplicacion
en caso de no haber puede eliminarse en un futuro
 */

export default makeState();
