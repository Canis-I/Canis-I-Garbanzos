import product_getters from "./product-getters";

export default {
  ...product_getters,
};
