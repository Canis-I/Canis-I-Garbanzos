import product_actions from "./product-actions";
import search_actions from "./search-actions";

export default {
  ...product_actions,
  ...search_actions,
};
